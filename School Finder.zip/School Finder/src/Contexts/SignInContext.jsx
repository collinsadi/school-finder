 import React, { createContext } from "react";

 export const SignInContext = React.createContext()